import { CostPipe } from './cost.pipe';

describe('CostPipe', () => {
  it('create an instance', () => {
    const pipe = new CostPipe();
    expect(pipe).toBeTruthy();
  });
});
