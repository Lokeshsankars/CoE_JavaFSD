import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'cost'
})
export class CostPipe implements PipeTransform {

  transform(value: number, discount?: number): string {
    let finalCost = value;
    if (discount && discount > 0 && discount <= 100) {
      finalCost = value - (value * discount / 100);
    }
    // Format as currency string (you can customize the format as needed)
    return '$' + finalCost.toFixed(2);
  }

}
