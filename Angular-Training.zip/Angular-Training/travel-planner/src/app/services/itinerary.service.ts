import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ItineraryService {
  private itineraryKey = 'itinerary';

  addDestination(destination: any): void {
    let currentItinerary = this.getItinerary();

    // Check if the destination already exists
    if (!currentItinerary.some((item) => item.id === destination.id)) {
      currentItinerary.push(destination);
      localStorage.setItem(this.itineraryKey, JSON.stringify(currentItinerary));
    }
  }

  getItinerary(): any[] {
    const stored = localStorage.getItem(this.itineraryKey);
    return stored ? JSON.parse(stored) : [];
  }
}
