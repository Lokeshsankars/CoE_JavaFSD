import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private userKey = 'users';
  private loggedInUserKey = 'loggedInUser';

  constructor(private router: Router) {}

  // Sign Up Method
  signup(user: { username: string; password: string }) {
    let users = this.getUsers();
    
    // Check if user already exists
    if (users.some(u => u.username === user.username)) {
      alert('Username already taken!');
      return false;
    }

    users.push(user);
    localStorage.setItem(this.userKey, JSON.stringify(users));
    alert('Signup Successful! Please log in.');
    this.router.navigate(['/login']);
    return true;
  }

  // Login Method
  login(username: string, password: string): boolean {
    let users = this.getUsers();
    let userExists = users.find(u => u.username === username && u.password === password);
    
    if (userExists) {
      localStorage.setItem(this.loggedInUserKey, username);
      return true;
    }
    
    alert('Invalid Credentials');
    return false;
  }

  // Logout Method
  logout() {
    localStorage.removeItem(this.loggedInUserKey);
    this.router.navigate(['/login']);
  }

  // Check if user is logged in
  isLoggedIn(): boolean {
    return !!localStorage.getItem(this.loggedInUserKey);
  }

  private getUsers(): { username: string; password: string }[] {
    return JSON.parse(localStorage.getItem(this.userKey) || '[]');
  }
}
