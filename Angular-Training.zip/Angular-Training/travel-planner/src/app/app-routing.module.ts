import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LandingComponent } from './landing/landing.component';
import { DestinationDetailComponent } from './destination-detail/destination-detail.component';
import { ItineraryComponent } from './itinerary/itinerary.component';
import { BookingComponent } from './booking/booking.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { AuthGuard } from './guards/auth.guard';


const routes: Routes = [
  { path: 'signup', component: SignupComponent },
  { path: '', component: LoginComponent },
  { path: 'Home', component: LandingComponent },
  { path: 'destination/:id', component: DestinationDetailComponent, canActivate: [AuthGuard] },
  { path: 'itinerary', component: ItineraryComponent },
  { path: 'booking/:id', component: BookingComponent },
  { path: '**', redirectTo: '' }, // fallback route

  { path: '**', redirectTo: 'login' }  



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}


// import { NgModule } from '@angular/core';
// import { RouterModule, Routes } from '@angular/router';
// import { LoginComponent } from './login/login.component';
// import { SignupComponent } from './signup/signup.component';
// import { DestinationDetailComponent } from './destination-detail/destination-detail.component';
// import { AuthGuard } from './guards/auth.guard';

// const routes: Routes = [
//   { path: 'signup', component: SignupComponent },
//   { path: 'login', component: LoginComponent },
//   { path: 'destinations', component: DestinationDetailComponent, canActivate: [AuthGuard] },
//   { path: '**', redirectTo: 'login' }
// ];

// @NgModule({
//   imports: [RouterModule.forRoot(routes)],
//   exports: [RouterModule]
// })
// export class AppRoutingModule { }
