import { Component, OnInit } from '@angular/core';
import { ItineraryService } from '../services/itinerary.service';

@Component({
  selector: 'app-itinerary',
  templateUrl: './itinerary.component.html',
  styleUrls: ['./itinerary.component.css']
})
export class ItineraryComponent implements OnInit {
  itinerary: any[] = [];

  constructor(private itineraryService: ItineraryService) {}

  ngOnInit(): void {
    this.itinerary = this.itineraryService.getItinerary();
  }
}
