import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { BookingService } from '../services/booking.service';
import { DestinationService } from '../services/destination.service';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {
  bookingForm: FormGroup;
  destination: any;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private bookingService: BookingService,
    private destinationService: DestinationService
  ) {
    this.bookingForm = this.fb.group({
      fullName: ['', Validators.required],
      travelDate: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    this.destinationService.getDestinationById(id).subscribe(data => {
      this.destination = data;
    });
  }

  submitBooking() {
    if (this.bookingForm.valid) {
      const bookingData = {
        destinationId: this.destination.id,
        fullName: this.bookingForm.value.fullName,
        travelDate: this.bookingForm.value.travelDate
      };
      this.bookingService.submitBooking(bookingData).subscribe(response => {
        alert('Booking confirmed!');
      });
    }
  }
}
