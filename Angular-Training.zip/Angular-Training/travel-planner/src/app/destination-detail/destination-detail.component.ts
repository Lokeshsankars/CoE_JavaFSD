import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DestinationService } from '../services/destination.service';
import { ItineraryService } from '../services/itinerary.service';

@Component({
  selector: 'app-destination-detail',
  templateUrl: './destination-detail.component.html',
  styleUrls: ['./destination-detail.component.css']
})
export class DestinationDetailComponent implements OnInit {
  destination: any;

  constructor(
    private route: ActivatedRoute,
    private destinationService: DestinationService,
    private itineraryService: ItineraryService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    this.destinationService.getDestinationById(id).subscribe(data => {
      this.destination = data;
    });
  }

  addToItinerary() {
    this.itineraryService.addDestination(this.destination);
    // Navigate to itinerary view after adding
    this.router.navigate(['/itinerary']);
  }
}
