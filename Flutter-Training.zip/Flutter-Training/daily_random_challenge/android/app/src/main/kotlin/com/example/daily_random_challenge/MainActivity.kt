package com.example.daily_random_challenge

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
