import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseService {
  static final FirebaseFirestore _db = FirebaseFirestore.instance;

  static Future<void> addChallenge(String challenge) async {
    await _db.collection('challenges').add({'challenge': challenge, 'date': DateTime.now()});
  }

  static Stream<QuerySnapshot> getCompletedChallenges() {
    return _db.collection('challenges').orderBy('date', descending: true).snapshots();
  }
}
