// lib/services/challenge_service.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/challenge.dart';

class ChallengeService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> completeChallenge(String userId, Challenge challenge) async {
    await _firestore
        .collection('users')
        .doc(userId)
        .collection('completedChallenges')
        .add({
      'title': challenge.title,
      'description': challenge.description,
      'completedAt': FieldValue.serverTimestamp(),
    });
  }
}
