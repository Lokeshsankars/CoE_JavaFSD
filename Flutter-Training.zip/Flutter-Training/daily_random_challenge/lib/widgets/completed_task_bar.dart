// lib/widgets/completed_task_bar.dart
import 'package:flutter/material.dart';

class CompletedTaskBar extends StatelessWidget {
  final int completedCount;
  const CompletedTaskBar({Key? key, required this.completedCount}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.grey.shade200,
      padding: EdgeInsets.all(8.0),
      child: Row(
        children: [
          Icon(Icons.check_circle, color: Colors.green),
          SizedBox(width: 8),
          Text("Completed Tasks: $completedCount"),
        ],
      ),
    );
  }
}
