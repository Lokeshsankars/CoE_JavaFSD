// lib/rewards/reward_service.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import '../rewards/reward_model.dart';

class RewardService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// Listen for changes in completed challenges and update rewards.
  Stream<Reward?> rewardsStream(String userId) {
    return _firestore
        .collection('users')
        .doc(userId)
        .collection('completedChallenges')
        .snapshots()
        .map((snapshot) {
      if (snapshot.docs.isEmpty) {
        return null; // No challenges completed yet
      }
      int count = snapshot.docs.length;
      String badge = _getBadgeForCount(count);
      return Reward(points: count, badge: badge);
    });
  }

  /// Determines the badge based on challenge completion count.
  String _getBadgeForCount(int count) {
    if (count >= 30) {
      return "Advanced Badge 🏆";  // Changed for better clarity
    } else if (count >= 10) {
      return "Intermediate Badge 🥇";
    } else if (count >= 5) {
      return "Beginner Badge 🥉";
    } else {
      return "No Badge Yet ❌";
    }
  }
}
