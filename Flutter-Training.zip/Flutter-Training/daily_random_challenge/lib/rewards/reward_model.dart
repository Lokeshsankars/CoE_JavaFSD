// lib/rewards/reward_model.dart
class Reward {
  final int points;
  final String badge;

  Reward({required this.points, required this.badge});

  factory Reward.fromMap(Map<String, dynamic> data) {
    return Reward(
      points: data['points'] ?? 0,
      badge: data['badge'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'points': points,
      'badge': badge,
    };
  }
}
