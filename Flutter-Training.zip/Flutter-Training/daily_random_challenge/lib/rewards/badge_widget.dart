// lib/rewards/badge_widget.dart
import 'package:flutter/material.dart';

class BadgeWidget extends StatefulWidget {
  final String badge;
  const BadgeWidget({Key? key, required this.badge}) : super(key: key);

  @override
  _BadgeWidgetState createState() => _BadgeWidgetState();
}

class _BadgeWidgetState extends State<BadgeWidget> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: Duration(milliseconds: 800),
      vsync: this,
    );
    _scaleAnimation = CurvedAnimation(parent: _controller, curve: Curves.elasticOut);
    if (widget.badge.isNotEmpty) {
      _controller.forward();
    }
  }

  @override
  void didUpdateWidget(covariant BadgeWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.badge != widget.badge && widget.badge.isNotEmpty) {
      _controller.forward(from: 0.0);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.badge.isEmpty) return SizedBox.shrink();
    return ScaleTransition(
      scale: _scaleAnimation,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.emoji_events, color: Colors.amber, size: 32),
          SizedBox(width: 8),
          Text(widget.badge, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}
