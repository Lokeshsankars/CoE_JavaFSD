// Example in settings_screen.dart or home_screen.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../rewards/reward_service.dart';
import '../rewards/badge_widget.dart';

class RewardsDisplay extends StatelessWidget {
  final String userId;
  const RewardsDisplay({Key? key, required this.userId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final rewardService = RewardService();
    return StreamBuilder(
      stream: rewardService.rewardsStream(userId),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return CircularProgressIndicator();
        final reward = snapshot.data!;
        return Column(
          children: [
            Text("Points: ${reward.points}"),
            BadgeWidget(badge: reward.badge),
          ],
        );
      },
    );
  }
}
