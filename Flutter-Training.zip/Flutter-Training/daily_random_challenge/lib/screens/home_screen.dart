// Example in home_screen.dart
import 'package:flutter/material.dart';
import '../widgets/custom_appbar.dart';
import '../widgets/completed_task_bar.dart';

class HomeScreen extends StatelessWidget {
  final int completedCount; // you can fetch this from provider or Firestore

  const HomeScreen({Key? key, this.completedCount = 0}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(title: 'Daily Random Challenge'),
      body: Column(
        children: [
          CompletedTaskBar(completedCount: completedCount),
          // ...rest of your home screen UI
        ],
      ),
    );
  }
}
