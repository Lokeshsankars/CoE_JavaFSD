import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/firebase_service.dart';

class CompletedScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Completed Challenges")),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseService.getCompletedChallenges(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
          return ListView(
            children: snapshot.data!.docs.map((doc) {
              return ListTile(title: Text(doc['challenge']));
            }).toList(),
          );
        },
      ),
    );
  }
}
