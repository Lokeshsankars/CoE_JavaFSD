import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:lottie/lottie.dart';
import 'package:firebase_auth/firebase_auth.dart';

class DailyChallengeScreen extends StatefulWidget {
  @override
  _DailyChallengeScreenState createState() => _DailyChallengeScreenState();
}

class _DailyChallengeScreenState extends State<DailyChallengeScreen> {
  String challengeTitle = "Loading...";
  String challengeDescription = "";
  String challengeDate = "";
  bool isDarkMode = false;
  int completedTasks = 0;
  int points = 0;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  @override
  void initState() {
    super.initState();
    loadDarkModePreference();
    loadUserStats();
    fetchDailyChallenge();
  }

  /// Load Dark Mode preference from local storage
  Future<void> loadDarkModePreference() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      isDarkMode = prefs.getBool('isDarkMode') ?? false;
    });
  }

  /// Toggle Dark Mode & Save Preference
  Future<void> toggleDarkMode() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      isDarkMode = !isDarkMode;
      prefs.setBool('isDarkMode', isDarkMode);
    });
  }

  /// Fetch Daily Challenge from Firestore
  void fetchDailyChallenge() async {
    String formattedDate = DateFormat('yyyy-MM-dd').format(DateTime.now());
    FirebaseFirestore.instance
        .collection('challenges')
        .where('date', isEqualTo: formattedDate)
        .get()
        .then((QuerySnapshot snapshot) {
      if (snapshot.docs.isNotEmpty) {
        var challenge = snapshot.docs.first.data() as Map<String, dynamic>;
        setState(() {
          challengeTitle = challenge['title'] ?? "No title available";
          challengeDescription = challenge['description'] ?? "No description available";
          challengeDate = formattedDate;
        });
      } else {
        setState(() {
          challengeTitle = "No challenge for today!";
          challengeDescription = "Come back tomorrow for a new challenge!";
          challengeDate = formattedDate;
        });
      }
    }).catchError((error) {
      setState(() {
        challengeTitle = "Error fetching challenge";
        challengeDescription = "Please try again later.";
        challengeDate = "";
      });
    });
  }

  /// Load User Stats (Points & Completed Tasks)
  Future<void> loadUserStats() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      completedTasks = prefs.getInt('completedTasks') ?? 5;
      points = prefs.getInt('points') ??5;
    });
  }

  /// Mark Challenge as Completed & Update Points
  Future<void> completeChallenge() async {
    User? user = _auth.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('You need to log in to complete challenges!')));
      return;
    }

    String userId = user.uid;
    String completionDate = DateFormat('yyyy-MM-dd').format(DateTime.now());

    DocumentReference challengeRef = FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .collection('completedChallenges')
        .doc(completionDate);

    FirebaseFirestore.instance.runTransaction((transaction) async {
      DocumentSnapshot challengeDoc = await transaction.get(challengeRef);

      if (!challengeDoc.exists) {
        transaction.set(challengeRef, {
          'title': challengeTitle,
          'description': challengeDescription,
          'date': completionDate,
          'completed': true,
        });

        // Update Points & Completed Tasks Locally
        SharedPreferences prefs = await SharedPreferences.getInstance();
        setState(() {
          completedTasks++;
          points += 10; // Increment points (can be adjusted)
          prefs.setInt('completedTasks', completedTasks);
          prefs.setInt('points', points);
        });
      }
    }).then((_) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Challenge marked as completed! 🎉')));
    }).catchError((error) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $error')));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: isDarkMode ? Colors.black : Colors.white,
      appBar: AppBar(
        title: Text(
          "Daily Challenge",
          style: TextStyle(color: isDarkMode ? Colors.white : Colors.black), // Ensure white text in dark mode
        ),
        backgroundColor: isDarkMode ? Colors.grey[900] : Colors.blueAccent,
        actions: [
          IconButton(
            icon: Icon(isDarkMode ? Icons.wb_sunny : Icons.nightlight_round),
            onPressed: toggleDarkMode,
          ),
        ],
      ),

      body: Center(
        child: Padding(
          padding: EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Lottie.asset('assets/challenge.json', height: 150),
              SizedBox(height: 20),

              /// **User Stats: Points & Completed Tasks**
              Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                elevation: 5,
                color: isDarkMode ? Colors.grey[850] : Colors.white,
                child: Padding(
                  padding: EdgeInsets.all(15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Column(
                        children: [
                          Text("Points",
                              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.blueAccent)),
                          Text("$points", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                        ],
                      ),
                      Column(
                        children: [
                          Text("Completed",
                              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.green)),
                          Text("$completedTasks", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 20),

              /// **Daily Challenge Card**
              Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                elevation: 5,
                color: isDarkMode ? Colors.grey[850] : Colors.white,
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Column(
                    children: [
                      Text(
                        challengeTitle,
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: isDarkMode ? Colors.white : Colors.black,
                        ),
                      ),
                      SizedBox(height: 10),
                      Text(
                        challengeDescription,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 18,
                          color: isDarkMode ? Colors.grey[400] : Colors.grey[700],
                        ),
                      ),
                      SizedBox(height: 10),
                      Text(
                        "Date: $challengeDate",
                        style: TextStyle(
                          fontSize: 16,
                          fontStyle: FontStyle.italic,
                          color: Colors.blueAccent,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 20),

              /// **Action Buttons**
              ElevatedButton(
                onPressed: completeChallenge,
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  backgroundColor: Colors.green,
                ),
                child: Text("Mark as Completed", style: TextStyle(fontSize: 18, color: Colors.white)),
              ),
              SizedBox(height: 10),

              ElevatedButton(
                onPressed: fetchDailyChallenge,
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  backgroundColor: Colors.blueAccent,
                ),
                child: Text("Fetch New Challenge", style: TextStyle(fontSize: 18, color: Colors.white)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
